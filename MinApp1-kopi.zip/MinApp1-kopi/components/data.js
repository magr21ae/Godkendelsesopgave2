const data = {
    41: ['Boller i karry', 'Pasta med kødsovs'],
    42: ['Stegt flæsk', 'Dahl'],
    // Tilføj data for andre uger her
  };
  
  export default data;