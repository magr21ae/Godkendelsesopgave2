Welcommen til min madplans app :)

For at køre appen skal du igennem følgende trin: 

1. Skriv: npm install, i terminalen

2. Start herefter appen: npm start

God fornøjelse!